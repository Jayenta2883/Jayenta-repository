from flask import Flask, render_template, request
from SmartApi.smartConnect import SmartConnect
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

API_KEY = os.getenv("API_KEY")
CLIENT_CODE = os.getenv("CLIENT_CODE")
PASSWORD = os.getenv("PASSWORD")
TOTP = os.getenv("TOTP")
SECRET_KEY = os.getenv("SECRET_KEY")

smart_api = SmartConnect(api_key=API_KEY)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        client_code = request.form['client_code']
        password = request.form['password']
        totp = request.form['totp']
        try:
            data = smart_api.generateSession(client_code, password, totp)
            profile = smart_api.getProfile(data['data']['refreshToken'])
            return f"<h2>Login Successful</h2><pre>{profile}</pre>"
        except Exception as e:
            return f"<h2>Login Failed</h2><pre>{str(e)}</pre>"
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')